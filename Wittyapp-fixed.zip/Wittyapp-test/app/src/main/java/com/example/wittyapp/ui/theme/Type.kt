package com.example.wittyapp.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
